jQuery(document).ready(function ($) {
if($("#owl-demo").length > 0){
           
		  $("#owl-demo").owlCarousel({
		    autoPlay : 3000,
		    loop:true,
		    stopOnHover : true,
		    navigation:true,
		    paginationSpeed : 1000,
		    goToFirstSpeed : 2000,
		    singleItem : true,
		    autoHeight : true,
		    // transitionStyle:"fade"
		  });
		  
  	}


if($(".matchcenterBtn").length > 0){
	$(".matchcenterBtn").click(function(){
		var match_slug = $(this).attr('data-attr');
		location.href = base_url+'game/'+match_slug;
	});
}


});

$(function(){
	newsAjax();
	$(window).scroll(function(){
		if ($(window).scrollTop() == $(document).height() - $(window).height()){
		  newsAjax();
		}
}); 
});
function newsAjax(){
	$(".ajaxloader").show();
	 $.ajax({
		   	  type:'POST',
		   	  url:base_url+'welcome/getAjaxnews',
		   	  data:{
		   	  	limit : $('#newsWrapper').attr('data-limit')
		   	  },
		   	  success:function(msg){
		   	  	 var data = $.parseJSON(msg);
		   	  	 var limit = data.limit;
		   	  	 $('#newsWrapper').attr('data-limit',limit);
		   	  	 $.each(data.news, function(idx, obj) {
					$('#newsWrapper').append('<li></li>');
					$('#newsWrapper').find('li').last().html(
						'<div class="newsTitle">'+obj.news_title+'</div><div><img src="'+obj.news_image+'" /></div><div class="newsDesc" >'+obj.news_description+'</div>'
					);
				});
		   	  }
		   }); 
	$(".ajaxloader").hide();
}
