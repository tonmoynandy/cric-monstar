
    <footer>
     <p>&copy; Copyright  by Developer PC</p>
    </footer>
