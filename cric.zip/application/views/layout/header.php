<?php  $current_class = $this->router->class;$current_method = $this->router->method;  ?>


    <header class="mainHeader">
      <div class="mainNav">
      	<div class="mainLogo">
      		Cric Star
      	</div>
      	<div class="mainMenuWrap">
      	<ul class="mainNavUl">
      		<li class="mainNavLi"><a href="<?php echo FRONTEND_URL; ?>">Home</a></li>
      		<li class="mainNavLi"><a href="#">Current Series</a>
      			<ul class="subnavUl slider">
      				<?php
            		 if(is_array($activeSeries) and count($activeSeries)>0){
            		 	foreach($activeSeries as $ser){?>
            		 	<li>
            		 		<a href="<?php echo FRONTEND_URL.'series/'.$ser['series_slug'] ?>">
            		 			<?php echo stripslashes($ser['s_name']) ?>
            		 		</a>
            		 	</li>	
            		<?php 	}
            		 }
            		?>
      			</ul>
      		</li>
      		<li class="mainNavLi"><a href="#">Upcoming Series</a>
      			<ul class="subnavUl">
      				<?php
            		 if(is_array($activeSchedule) and count($activeSchedule)>0){
            		 	foreach($activeSchedule as $ser){?>
            		 	<li>
            		 		<a href="<?php echo FRONTEND_URL.'series/'.$ser['series_slug'] ?>">
            		 			<?php echo stripslashes($ser['s_name']) ?>
            		 		</a>
            		 	</li>	
            		<?php 	}
            		 }
            		?>
      			</ul>
      		</li>
      		<li class="mainNavLi"><a href="<?php echo FRONTEND_URL.'news' ?>">News</a></li>
      	</ul>
      	</div>
      </div>
    </header>
