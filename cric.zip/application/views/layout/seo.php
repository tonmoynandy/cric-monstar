  <meta charset="utf-8" />
  <!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame 
       Remove this if you use the .htaccess -->
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

  <title><?php echo $page_title; ?></title>
  <meta name="description" content="<?php echo $page_mata_description; ?>" />
  <meta name="author" content="<?php echo $page_mata_keyword ?>" />

  <meta name="viewport" content="width=device-width; initial-scale=1.0" />
  