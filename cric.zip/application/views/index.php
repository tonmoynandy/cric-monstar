    <div class="bodyWrapper">
	<div class="matchHeader headerLayout1">
        <!-- Jssor Slider Begin -->
        <!-- You can move inline styles to css file or css block. -->
        <!-- ================================================== -->
        
            <!-- Loading Screen -->

            <!-- Slides Container -->
             <div id="owl-demo" class="owl-carousel">
                 <?php if(is_array($liveGame) and count($liveGame)>0){?>
                 	<?php foreach($liveGame as $index=>$game){ ?>
                 		<div class="main_slider_container">
                		
                		<div class="main_slider_body">
                		
                			<div class="seriesDetailsContainer">
							 	 <span class="detailsContainerHeader">
							 	<?php echo stripslashes($game['series_name']); ?>
							 	 </span>
							 	 <br/>
							 	 
							 </div>
                			<div class="matchHeaderContainer">
		                		<div class="gameDetails">
		                			<div class="subteam teamLogo">
		                				<span class="team <?php echo strtoupper($game['first_team_name']); ?>"></span>
		                			</div>
		                		</div>
		                		<div class="gameDetails">
		                			<p><?php echo stripslashes($game['play_name']); ?></p>
		                			<p><?php echo stripslashes($game['play_ground']); ?></p>
		                		</div>
		                		<div class="gameDetails">
									 	<div class="subteam teamLogo">
									
											<span class="team <?php echo strtoupper($game['last_team_name']); ?>"></span>
										</div>
								</div>
							</div>
							<div class="slider_footer">
								<p align="center">
	                				<button class="btn btn-primary matchcenterBtn custom-matchcenter-btn" data-attr="<?php echo $game['play_slug']; ?>">Match Center</button>
	                			</p>
							</div>
						</div>
						
                	</div>	
                 	<?php } ?>
                 <?php } ?>
                	
                                   
            </div>


        <!-- Jssor Slider End -->
    </div>
<div class="mainWrapper">
	<div class="ajaxloader"></div>
	<ul class="newsUl" id="newsWrapper" data-limit='0'></ul>
	
</div>
