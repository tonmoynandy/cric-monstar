<!DOCTYPE html>
<html lang="en">
<head>
  
<?=isset($content_for_layout_seo)?$content_for_layout_seo:'';?>

<link rel="stylesheet" type="text/css" href="<?php echo FRONTEND_CSS_PATH; ?>style.css" media="all" />
<link rel="stylesheet" type="text/css" href="<?php echo FRONTEND_CSS_PATH; ?>owl.carousel.css" media="all" />
<script type="text/javascript" src="<?php echo FRONTEND_JS_PATH; ?>jquery-1.9.1.js"></script>
<script type="text/javascript" src="<?php echo FRONTEND_JS_PATH; ?>owl.carousel.min.js"></script>
<script type="text/javascript" src="<?php echo FRONTEND_JS_PATH; ?>custom.js"></script>

<script>
	$(function(){

	});

	$(function(){


		$(".customTabContent .subTabContent").addClass('inactive');
		$(".customTab .tab-link").click(function(){
		  var index =$(".customTab .tab-link").index($(this));
		  $(".customTabContent .subTabContent").addClass('inactive');
		  $(".customTabContent .subTabContent").removeClass('active');
		  $(".customTabContent .subTabContent:eq("+index+")").addClass('active');
		  $(".customTabContent .subTabContent:eq("+index+")").removeClass('inactive');
		});
		$(".customTab .tab-link:eq(0)").trigger('click');
/* Mobile */
		$('#mainMenuWrap').prepend('<div id="menu-trigger">Menu</div>');		
		$("#menu-trigger").on("click", function(){
			$("#menu").slideToggle();
		});

		// iPad
		var isiPad = navigator.userAgent.match(/iPad/i) != null;
		if (isiPad) $('#menu ul').addClass('no-transition');    		
	});

</script>

<script>var base_url ="<?php echo FRONTEND_URL; ?>"</script>
</head>

<body>
  <div class="mainWrapper">
  <!--START : top navigation is loaded here-->
	<?=isset($content_for_layout_header)?$content_for_layout_header:'';?>             			
  <!--END : top navigation here-->
  	<?=isset($content_for_layout_middle)?$content_for_layout_middle:'';?>
  	
  	<?=isset($content_for_layout_footer)?$content_for_layout_footer:'';?> 
  </div>
</body>
</html>