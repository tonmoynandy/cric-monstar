
    <div class="bodyWrapper scheduleWrapper">

	
	<div class="mainWrapper">
		<div class="matchHeader headerLayout2">
		 <div class="seriesDetailsContainer">
		 	 <span class="detailsContainerHeader">
		 	 	<?php echo stripslashes($series_details['s_name']); ?>
		 	 </span>
		 </div> 
		 </div>
		 
		 <div class="seriesScheduleDetails">
		 	<div class="sub-series-schedule">
		 	<?php if(is_array($series_schedule) and count($series_schedule)>0){
		 		foreach ($series_schedule as $index=>$game){ ?>
		 			<div class="matchHeaderContainer ">
		 				<div class="gameDetails">
		 					    <div class="gameTeamcontainer">
		                			<span class="team <?php echo strtoupper($game['first_team_name']); ?>"></span>
		                		</div>
		                </div>
						<div class="gameDetails">
		 						<div class="gameActioncontainer">
		                			<p><strong><?php echo stripslashes($game['play_name']); ?></strong> 
		                				at 
		                				<?php echo stripslashes($game['play_ground']); ?>
		                			</p>
		                			<p><?php echo ($game['play_start_date']);
									   if($game['play_start_date']!= $game['play_end_date']){
									   	echo ' - '.$game['play_end_date'];
									   }
									 ?>
									 </p>
									 <p>
									 <?php echo " GMT: ".stripslashes($game['gmt_time']); ?>
									 <?php echo " IST: ".stripslashes($game['ist_time']); ?>
									 </p>
									 
		                		</div>
		                		<div class="gameActioncontainer">
		                			<?php if($game['play_start_date'] <= date('Y-m-d')){ ?>
		                			<p>
		                				<button class="btn btn-primary matchcenterBtn custom-matchcenter-btn" data-attr="<?php echo $game['play_slug']; ?>">Match Center</button>
		                			</p>
		                			<?php } ?>
		                		</div>
		 				</div>
		                <div class="gameDetails">
		                		<div class="gameTeamcontainer">
									<span class="team <?php echo strtoupper($game['last_team_name']); ?>"></span>
								</div>
		 				</div>
		 				
		 				<div class="allClear"></div>
		 			</div>
		 	<?php	}
		 	} ?>
		 </div>
		 </div>
	</div>
</div>