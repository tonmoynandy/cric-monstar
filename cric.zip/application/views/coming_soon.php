    

    <div class="bodyWrapper">
    	<p align="center">
    	<img width="500" src="<?php echo base_url().'img/coming-soon.png' ?>" />
    	</p>
    </div>
